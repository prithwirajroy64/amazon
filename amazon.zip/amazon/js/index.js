function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
};

let overlay = document.querySelector(".overlay");
let popup = document.querySelector(".popup");

function showPopUp(){
    overlay.classList.add("show");
    popup.classList.add("show");
    console.log(overlay);
    console.log(popup);
}
function hidePopUp(){
    overlay.classList.remove("show");
    popup.classList.remove("show");
}